
package T2;
import javax.swing.*;

public class act4 extends JFrame {
    JTextField txtBase = new JTextField();
    JTextField txtExponente = new JTextField();
    JLabel etiResultado = new JLabel("Resultado:");
    JButton btnCalcular = new JButton("Calcular");

    public act4() {
        setLayout(null);
        setTitle("Ejercicio 4");
        setSize(300, 200);

        txtBase.setBounds(20, 20, 100, 25);
        txtExponente.setBounds(20, 60, 100, 25);
        btnCalcular.setBounds(20, 100, 100, 25);
        etiResultado.setBounds(20, 140, 200, 20);

        add(txtBase);
        add(txtExponente);
        add(btnCalcular);
        add(etiResultado);

        btnCalcular.addActionListener(e -> {
            double base = Double.parseDouble(txtBase.getText());
            double exp = Double.parseDouble(txtExponente.getText());
            double res = Math.pow(base, exp);
            etiResultado.setText("Resultado: " + res);
        });

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}
