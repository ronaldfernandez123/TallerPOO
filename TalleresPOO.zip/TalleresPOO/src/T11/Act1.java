package T11;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Act1 extends JFrame {
    private JToggleButton botonUno, botonDos, botonTres, botonCuatro, botonCinco, botonSeis;
    private JButton btnDesactivarTodos, btnActivarTodos, btnTotal;
    private JLabel etiResultado;

    public Act1() {
        setTitle("Toggle Buttons y Acciones");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        botonUno = new JToggleButton("1");
        botonDos = new JToggleButton("2");
        botonTres = new JToggleButton("3");
        botonCuatro = new JToggleButton("4");
        botonCinco = new JToggleButton("5");
        botonSeis = new JToggleButton("6");

        btnDesactivarTodos = new JButton("Desactivar Todos");
        btnActivarTodos = new JButton("Activar Todos");
        btnTotal = new JButton("Total");

        etiResultado = new JLabel("Resultado: 0");
        etiResultado.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        add(botonUno);
        add(botonDos);
        add(botonTres);
        add(botonCuatro);
        add(botonCinco);
        add(botonSeis);
        add(btnDesactivarTodos);
        add(btnActivarTodos);
        add(btnTotal);
        add(etiResultado);

        btnTotal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int total = 0;

                if (botonUno.isSelected()) total += 1;
                if (botonDos.isSelected()) total += 2;
                if (botonTres.isSelected()) total += 3;
                if (botonCuatro.isSelected()) total += 4;
                if (botonCinco.isSelected()) total += 5;
                if (botonSeis.isSelected()) total += 6;

                etiResultado.setText("Resultado: " + total);
            }
        });

        btnDesactivarTodos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                botonUno.setSelected(false);
                botonDos.setSelected(false);
                botonTres.setSelected(false);
                botonCuatro.setSelected(false);
                botonCinco.setSelected(false);
                botonSeis.setSelected(false);
            }
        });

        btnActivarTodos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                botonUno.setSelected(true);
                botonDos.setSelected(true);
                botonTres.setSelected(true);
                botonCuatro.setSelected(true);
                botonCinco.setSelected(true);
                botonSeis.setSelected(true);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Act1().setVisible(true);
            }
        });
    }
}
