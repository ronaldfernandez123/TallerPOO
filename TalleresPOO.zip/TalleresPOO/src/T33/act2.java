
package T33;


public class act2 {
    
 private int valor;
    private String nombre;
    private String apellidos;
    private String movil;

    // Constructor
    public act2(int valor, String nombre, String apellidos, String movil) {
        this.valor = valor;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.movil = movil;
    }

    // Métodos getter y setter
    public int getNumero() { return valor; }
    public void setNumero(int valor) { this.valor = valor; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }
    public String getMovil() { return movil; }
    public void setMovil(String movil) { this.movil = movil; }
}
