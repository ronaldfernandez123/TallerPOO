package T1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class act5 extends JFrame {
    private JLabel lblTexto1, lblTexto2, lblTexto3, lblTexto4, lblZonaOculta;

    public act5() {
        setLayout(null);
        setTitle("Ocultar Palabras");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        lblTexto1 = new JLabel("Texto A");
        lblTexto2 = new JLabel("Texto B");
        lblTexto3 = new JLabel("Texto C");
        lblTexto4 = new JLabel("Texto D");
        lblZonaOculta = new JLabel("Ocultar Todo", SwingConstants.CENTER);

        lblTexto1.setBounds(50, 50, 100, 30);
        lblTexto2.setBounds(150, 50, 100, 30);
        lblTexto3.setBounds(50, 100, 100, 30);
        lblTexto4.setBounds(150, 100, 100, 30);
        lblZonaOculta.setBounds(100, 180, 200, 50);
        lblZonaOculta.setOpaque(true);
        lblZonaOculta.setBackground(Color.LIGHT_GRAY);
        lblZonaOculta.setFont(new Font("Arial", Font.BOLD, 16));

        add(lblTexto1);
        add(lblTexto2);
        add(lblTexto3);
        add(lblTexto4);
        add(lblZonaOculta);

        lblZonaOculta.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                lblTexto1.setVisible(false);
                lblTexto2.setVisible(false);
                lblTexto3.setVisible(false);
                lblTexto4.setVisible(false);
            }

            public void mouseExited(MouseEvent e) {
                lblTexto1.setVisible(true);
                lblTexto2.setVisible(true);
                lblTexto3.setVisible(true);
                lblTexto4.setVisible(true);
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new act5().setVisible(true);
    }
}
