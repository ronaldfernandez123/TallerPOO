package T1;

import javax.swing.*;

public class act1 extends JFrame {
    private JLabel lblPersona, lblLugar;
    private JButton btnEsconderPersona, btnMostrarPersona, btnEsconderLugar, btnMostrarLugar;

    public act1() {
        setTitle("Control de Visibilidad");
        setSize(400, 250);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar ventana

        // Etiquetas
        lblPersona = new JLabel("Andrea");
        lblPersona.setBounds(50, 30, 150, 25);
        add(lblPersona);

        lblLugar = new JLabel("Medellín");
        lblLugar.setBounds(50, 60, 150, 25);
        add(lblLugar);

        // Botones para ocultar/mostrar persona
        btnEsconderPersona = new JButton("Esconder Persona");
        btnEsconderPersona.setBounds(50, 100, 140, 30);
        add(btnEsconderPersona);

        btnMostrarPersona = new JButton("Mostrar Persona");
        btnMostrarPersona.setBounds(200, 100, 140, 30);
        add(btnMostrarPersona);

        // Botones para ocultar/mostrar lugar
        btnEsconderLugar = new JButton("Esconder Lugar");
        btnEsconderLugar.setBounds(50, 140, 140, 30);
        add(btnEsconderLugar);

        btnMostrarLugar = new JButton("Mostrar Lugar");
        btnMostrarLugar.setBounds(200, 140, 140, 30);
        add(btnMostrarLugar);

        // Acciones de los botones
        btnEsconderPersona.addActionListener(e -> lblPersona.setVisible(false));
        btnMostrarPersona.addActionListener(e -> lblPersona.setVisible(true));
        btnEsconderLugar.addActionListener(e -> lblLugar.setVisible(false));
        btnMostrarLugar.addActionListener(e -> lblLugar.setVisible(true));
    }

    public static void main(String[] args) {
        new act1().setVisible(true);
    }
}
