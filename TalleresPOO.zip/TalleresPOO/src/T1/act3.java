package T1;

import javax.swing.*;
import java.awt.event.*;

public class act3 extends JFrame {
    private JTextField campoEntrada;
    private JLabel lblResultado;
    private JButton btnLimpiar;

    public act3() {
        setLayout(null);
        setTitle("Texto en Vivo");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        campoEntrada = new JTextField();
        campoEntrada.setBounds(50, 30, 200, 25);
        add(campoEntrada);

        lblResultado = new JLabel("");
        lblResultado.setBounds(50, 70, 200, 25);
        add(lblResultado);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(50, 110, 100, 25);
        add(btnLimpiar);

        campoEntrada.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                lblResultado.setText(campoEntrada.getText());
            }
        });

        btnLimpiar.addActionListener(e -> {
            campoEntrada.setText("");
            lblResultado.setText("");
        });
    }

    public static void main(String[] args) {
        new act3().setVisible(true);    }
}
