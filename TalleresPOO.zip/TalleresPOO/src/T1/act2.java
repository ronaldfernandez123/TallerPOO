package T1;

import javax.swing.*;

public class act2 extends JFrame {
    private JTextField campoEntrada;
    private JLabel lblDestinoA, lblDestinoB;
    private JButton btnCopiarA, btnCopiarB;

    public act2() {
        setTitle("Transferencia de Texto");
        setSize(420, 200);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        campoEntrada = new JTextField();
        campoEntrada.setBounds(50, 20, 250, 25);
        add(campoEntrada);

        lblDestinoA = new JLabel("");
        lblDestinoA.setBounds(50, 60, 200, 20);
        add(lblDestinoA);

        lblDestinoB = new JLabel("");
        lblDestinoB.setBounds(50, 90, 200, 20);
        add(lblDestinoB);

        btnCopiarA = new JButton("Copiar a A");
        btnCopiarA.setBounds(310, 60, 100, 25);
        add(btnCopiarA);

        btnCopiarB = new JButton("Copiar a B");
        btnCopiarB.setBounds(310, 90, 100, 25);
        add(btnCopiarB);

        btnCopiarA.addActionListener(e -> lblDestinoA.setText(campoEntrada.getText()));
        btnCopiarB.addActionListener(e -> lblDestinoB.setText(campoEntrada.getText()));
    }

    public static void main(String[] args) {
        new act2().setVisible(true);

    }
}
