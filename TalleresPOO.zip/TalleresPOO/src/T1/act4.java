package T1;

import javax.swing.*;

public class act4 extends JFrame {
    private JTextField campoNombre, campoCiudad;
    private JLabel etiquetaResultado;
    private JButton btnMostrar, btnBloquear, btnHabilitar;

    public act4() {
        setLayout(null);
        setTitle("Formulario");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        campoNombre = new JTextField();
        campoNombre.setBounds(50, 30, 150, 25);
        add(campoNombre);

        campoCiudad = new JTextField();
        campoCiudad.setBounds(50, 60, 150, 25);
        add(campoCiudad);

        etiquetaResultado = new JLabel("");
        etiquetaResultado.setBounds(50, 100, 300, 25);
        add(etiquetaResultado);

        btnMostrar = new JButton("Mostrar");
        btnMostrar.setBounds(50, 140, 100, 25);
        add(btnMostrar);

        btnBloquear = new JButton("Bloquear");
        btnBloquear.setBounds(160, 140, 100, 25);
        add(btnBloquear);

        btnHabilitar = new JButton("Habilitar");
        btnHabilitar.setBounds(270, 140, 100, 25);
        add(btnHabilitar);

        btnMostrar.addActionListener(e -> {
            String nombre = campoNombre.getText();
            String ciudad = campoCiudad.getText();
            etiquetaResultado.setText("Te llamas " + nombre + " y vives en " + ciudad + ".");
        });

        btnBloquear.addActionListener(e -> {
            campoNombre.setEnabled(false);
            campoCiudad.setEnabled(false);
        });

        btnHabilitar.addActionListener(e -> {
            campoNombre.setEnabled(true);
            campoCiudad.setEnabled(true);
        });
    }

    public static void main(String[] args) {
        new act4().setVisible(true);
    }
}
