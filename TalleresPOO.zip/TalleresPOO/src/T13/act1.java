import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class act1 extends JFrame {

    private JSpinner spiCentenas, spiDecenas, spiUnidades;
    private JButton btnAbrir;
    private JLabel etiResultado;

    public act1() {
        setTitle("Juego de Combinación");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2, 5, 5));

        spiCentenas = new JSpinner(new SpinnerNumberModel(0, 0, 9, 1));
        spiDecenas = new JSpinner(new SpinnerNumberModel(0, 0, 9, 1));
        spiUnidades = new JSpinner(new SpinnerNumberModel(0, 0, 9, 1));

        btnAbrir = new JButton("Abrir");

        etiResultado = new JLabel("Resultado: ", SwingConstants.CENTER);
        etiResultado.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        add(new JLabel("Centenas:"));
        add(spiCentenas);
        
        add(new JLabel("Decenas:"));
        add(spiDecenas);
        
        add(new JLabel("Unidades:"));
        add(spiUnidades);
        
        add(btnAbrir);
        add(etiResultado);

        btnAbrir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirCaja();
            }
        });
    }

    private void abrirCaja() {
        int centenas = Integer.parseInt(spiCentenas.getValue().toString());
        int decenas = Integer.parseInt(spiDecenas.getValue().toString());
        int unidades = Integer.parseInt(spiUnidades.getValue().toString());

        int valor = centenas * 100 + decenas * 10 + unidades;

        if (valor == 246) {
            etiResultado.setText("Caja Abierta");
        } else if (valor < 246) {
            etiResultado.setText("El número secreto es mayor");
        } else {
            etiResultado.setText("El número secreto es menor");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new act1().setVisible(true);
            }
        });
    }
}
