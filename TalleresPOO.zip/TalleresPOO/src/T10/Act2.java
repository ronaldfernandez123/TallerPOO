package T10;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Act2 extends JFrame {
    private JList<String> lstMeses;
    private JButton btnRellenar, btnVaciar;
    private JRadioButton optTri1, optTri2, optTri3, optTri4;
    private JLabel etiMes;
    private ButtonGroup grupoTrimestres;

    public Act2() {
        setTitle("Seleccionar Trimestre");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        lstMeses = new JList<>();
        JScrollPane scrollPane = new JScrollPane(lstMeses);

        optTri1 = new JRadioButton("Trimestre 1");
        optTri2 = new JRadioButton("Trimestre 2");
        optTri3 = new JRadioButton("Trimestre 3");
        optTri4 = new JRadioButton("Trimestre 4");

        grupoTrimestres = new ButtonGroup();
        grupoTrimestres.add(optTri1);
        grupoTrimestres.add(optTri2);
        grupoTrimestres.add(optTri3);
        grupoTrimestres.add(optTri4);

        JPanel panelTrimestres = new JPanel();
        panelTrimestres.setLayout(new GridLayout(4, 1));
        panelTrimestres.add(optTri1);
        panelTrimestres.add(optTri2);
        panelTrimestres.add(optTri3);
        panelTrimestres.add(optTri4);

        btnRellenar = new JButton("Rellenar");
        btnVaciar = new JButton("Vaciar");

        etiMes = new JLabel("Mes: ");
        etiMes.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        add(new JLabel("Seleccione un Trimestre"));
        add(panelTrimestres);
        add(btnRellenar);
        add(btnVaciar);
        add(scrollPane);
        add(etiMes);

        btnRellenar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultListModel<String> model = new DefaultListModel<>();
                if (optTri1.isSelected()) {
                    model.addElement("Enero");
                    model.addElement("Febrero");
                    model.addElement("Marzo");
                } else if (optTri2.isSelected()) {
                    model.addElement("Abril");
                    model.addElement("Mayo");
                    model.addElement("Junio");
                } else if (optTri3.isSelected()) {
                    model.addElement("Julio");
                    model.addElement("Agosto");
                    model.addElement("Septiembre");
                } else if (optTri4.isSelected()) {
                    model.addElement("Octubre");
                    model.addElement("Noviembre");
                    model.addElement("Diciembre");
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, seleccione un trimestre.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                lstMeses.setModel(model);
            }
        });

        btnVaciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lstMeses.setModel(new DefaultListModel<>());
            }
        });

        lstMeses.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String mesSeleccionado = lstMeses.getSelectedValue();
                if (mesSeleccionado != null) {
                    etiMes.setText("Mes: " + mesSeleccionado);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Act2().setVisible(true);
            }
        });
    }
}
